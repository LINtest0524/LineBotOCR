✅ Render 部署完成後，請將你的 LINE Webhook URL 設定為：
https://你的子網域.onrender.com/callback

✅ 並在 Render 的環境變數設定：
LINE_CHANNEL_ACCESS_TOKEN=你的 LINE bot 權杖

⚠️ 程式已改為從環境變數取得 token，不再寫死在程式內。